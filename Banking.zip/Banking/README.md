# The-Sparks-Foundation
Sparks Foundation Internship Project : Basic Banking System  
A Web Application used to transfer money between multiple users (Project contains 10 dummy users). 


Stack used -


Front-end : HTML, CSS, Bootstrap & Javascript 

Back-end : PHP 

Database : MySQL   


